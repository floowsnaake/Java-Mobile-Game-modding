#include <iostream>
#include <fstream>

int main(int argc, char* argv[]) {
	std::ifstream stream;
	stream.open("pizza.raw", std::ios_base::binary);

	if (!stream.bad()) {
		std::cout << std::hex;
		std::cout.width(2);


			unsigned char a;
			unsigned char b;
			unsigned char c;

			stream >> a;
            stream >> b;
            stream >> c;

			std::cout << static_cast<unsigned>(a);
			std::cout << "Hello, World!";
			std::cout << static_cast<unsigned>(b);
            std::cout << static_cast<unsigned>(c);

	}

	return 0;
}
