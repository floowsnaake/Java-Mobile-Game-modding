#include <iostream>
#include <fstream>

int main(int argc, char* argv[]) {
	std::ifstream stream;
	stream.open("pizza.raw", std::ios_base::binary);
	if (!stream.bad()) {
		std::cout << std::hex;
		std::cout.width(2);

		while (!stream.eof()) {
			unsigned char c;
			stream >> c;
			std::cout << static_cast<unsigned>(c);
		}
	}

	return 0;
}
